schedule1_multi_block1 <- readRDS("fitted_data/rat1_multi_block1_fit.rda")
schedule2_multi_block1 <- readRDS("fitted_data/rat2_multi_block1_fit.rda")
schedule1_multi_block2 <- readRDS("fitted_data/rat1_multi_block2_fit.rda")
schedule2_multi_block2 <- readRDS("fitted_data/rat2_multi_block2_fit.rda")
schedule1_multi_block41 <- readRDS("fitted_data/rat1_multi_block41_fit.rda")
schedule2_multi_block41 <- readRDS("fitted_data/rat2_multi_block41_fit.rda")

rat1_clean = read.csv("clean_data/rat1_clean.csv")
rat2_clean = read.csv("clean_data/rat2_clean.csv")
survey1 = read.csv('clean_data/survey1_clean.csv')
survey2 = read.csv('clean_data/survey2_clean.csv')


schedule1_multi_block1_pars <- rstan::extract(schedule1_multi_block1)
schedule2_multi_block1_pars <- rstan::extract(schedule2_multi_block1)
schedule1_multi_block2_pars <- rstan::extract(schedule1_multi_block2)
schedule2_multi_block2_pars <- rstan::extract(schedule2_multi_block2)
schedule1_multi_block3_pars <- rstan::extract(schedule1_multi_block3)
schedule2_multi_block3_pars <- rstan::extract(schedule2_multi_block3)
schedule1_multi_block4_pars <- rstan::extract(schedule1_multi_block4)
schedule2_multi_block4_pars <- rstan::extract(schedule2_multi_block4)
schedule1_multi_block41_pars <- rstan::extract(schedule1_multi_block41)
schedule2_multi_block41_pars <- rstan::extract(schedule2_multi_block41)


# plot correlation between learning rate difference and GCBS and STAI scores (including both schedule1 and schedule2)
lmp <- function (modelobject) {
  if (class(modelobject) != "lm") stop("Not an object of class 'lm' ")
  f <- summary(modelobject)$fstatistic
  p <- pf(f[1],f[2],f[3],lower.tail=F)
  attributes(p) <- NULL
  return(p)
}
plot_cor = function(schedule1_pars, schedule2_pars, 
                    schedule1_dat, schedule2_dat,
                    survey1 = survey1,
                    survey2 = survey2,
                    par_names = NULL, save_name){
  participantId = c(unique(schedule1_dat$subjID), unique(schedule2_dat$subjID))
  p_df = data.frame(matrix(ncol = 3, nrow = length(par_names)))
  colnames(p_df) = c("par_name", "cor_GCBS", 'cor_STAI')
  i = 1
  for(par_name in par_names){
    df = data.frame(matrix(ncol = 4, nrow = length(participantId)))
    colnames(df) = c('participantId', 'stable', 'volatile', 'diff')
    df['participantId'] = participantId
    
    df['stable'] = c(colMeans(schedule1_pars[[par_name]][,,1]),
                     colMeans(schedule2_pars[[par_name]][,,2]))
    df['volatile'] = c(colMeans(schedule1_pars[[par_name]][,,2]), 
                       colMeans(schedule2_pars[[par_name]][,,1]))
    df['diff'] = log(df['volatile']) - log(df['stable'])
    temp = merge(df, survey1[, c('participantId', 'GCBS')], by = "participantId")
    df = merge(temp, survey2[, c('participantId', 'STAI')], by = "participantId")

    h1 = ggplot(df, aes(x=GCBS, y=diff)) +
         geom_point(size=2) +
         geom_smooth(method = "lm", se = FALSE) +
         xlab(expression(GCBS)) +
         ylab(expression(diff))+
         theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
               panel.background = element_blank(), axis.line = element_line(colour = "black"))
    h2 = ggplot(df, aes(x=STAI, y=diff)) +
         geom_point(size=2) +
         geom_smooth(method = "lm", se = FALSE) +
         xlab(expression(STAI)) +
         ylab(expression(diff))+
         theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
               panel.background = element_blank(), axis.line = element_line(colour = "black"))
    
   h_all = plot_grid(h1,h2, rel_widths = c(2, 2), rel_heights = c(0.5, 0.5), nrow = 1)
   ggsave(filename=paste0("plots/multi_block/", save_name[i], ".png"), plot = h_all, width = 5, height = 5)
   
   p1 = lm(diff ~ GCBS, data = df) 
   p2 = lm(diff ~ STAI, data = df)
   p_df[i,] = c(par_name, lmp(p1), lmp(p2))
   i = i + 1
  }
  return(p_df)
 }

multi_block1_cor = plot_cor(schedule1_pars = schedule1_multi_block1_pars, 
         schedule2_pars = schedule2_multi_block1_pars, 
         schedule1_dat = rat1_clean, 
         schedule2_dat = rat2_clean, 
         survey1 = survey1,
         survey2 = survey2,
         par_names = c("A", "beta", "gamma"), 
         save_name = c("multi_block1_A_cor",
                       "multi_block1_beta_cor",
                       "multi_block1_gamma_cor"))

multi_block2_cor = plot_cor(schedule1_pars = schedule1_multi_block2_pars, 
                  schedule2_pars = schedule2_multi_block2_pars, 
                  schedule1_dat = rat1_clean, 
                  schedule2_dat = rat2_clean, 
                  survey1 = survey1,
                  survey2 = survey2,
                  par_names = c("A", "beta", "gamma"), 
                  save_name = c("multi_block2_A_cor",
                                "multi_block2_beta_cor",
                                "multi_block2_gamma_cor"))

multi_block3_cor = plot_cor(schedule1_pars = schedule1_multi_block3_pars, 
                            schedule2_pars = schedule2_multi_block3_pars, 
                            schedule1_dat = rat1_clean, 
                            schedule2_dat = rat2_clean, 
                            survey1 = survey1,
                            survey2 = survey2,
                            par_names = c("A", "beta", "gamma"), 
                            save_name = c("multi_block3_A_cor",
                                          "multi_block3_beta_cor",
                                          "multi_block3_gamma_cor"))

multi_block4_cor = plot_cor(schedule1_pars = schedule1_multi_block4_pars, 
                            schedule2_pars = schedule2_multi_block4_pars, 
                            schedule1_dat = rat1_clean, 
                            schedule2_dat = rat2_clean, 
                            survey1 = survey1,
                            survey2 = survey2,
                            par_names = c("A", "beta", "gamma"), 
                            save_name = c("multi_block4_A_cor",
                                          "multi_block4_beta_cor",
                                          "multi_block4_gamma_cor"))

multi_block4_cor = plot_cor(schedule1_pars = schedule1_multi_block41_pars, 
                            schedule2_pars = schedule2_multi_block41_pars, 
                            schedule1_dat = rat1_clean, 
                            schedule2_dat = rat2_clean, 
                            survey1 = survey1,
                            survey2 = survey2,
                            par_names = c("A", "beta", "gamma"), 
                            save_name = c("multi_block41_A_cor",
                                          "multi_block41_beta_cor",
                                          "multi_block41_gamma_cor"))

##############  ANOVA test of learning rates in stable and volatile, and difference of learning rates in two schedules
df2 = data.frame(matrix(ncol = 4, nrow =length(participantId)))
colnames(df2) = c('stable', 'volatile', 'diff', 'schedule')
df2['stable'] = c(colMeans(schedule1_multi_block41_pars[['A']][,,1]),
                 colMeans(schedule2_multi_block41_pars[['A']][,,2]))
df2['volatile'] = c(colMeans(schedule1_multi_block41_pars[['A']][,,2]), 
                   colMeans(schedule2_multi_block41_pars[['A']][,,1]))
df2['diff'] = log(df2['volatile']) - log(df2['stable'])
df2['schedule'] = c(rep('schedule1', 26), rep('schedule2', 13))
one.way <- aov(diff ~ schedule, data = df2)
summary(one.way)

df1 = data.frame(matrix(ncol = 2, nrow = 2*length(participantId)))
df1['LR'] = c(colMeans(schedule1_multi_block4_pars[['A']][,,1]),
              colMeans(schedule2_multi_block4_pars[['A']][,,2]),
              colMeans(schedule1_multi_block4_pars[['A']][,,2]),
              colMeans(schedule2_multi_block4_pars[['A']][,,1]))
df1['condition'] = c(rep('stable', length(participantId)), rep('volatile', length(participantId)))
one.way <- aov(LR ~ condition, data = df1)
summary(one.way)

################### stable and volatile correlation #############################
cor(colMeans(schedule1_multi_block1_pars$A[,,1]), colMeans(schedule1_multi_block1_pars$A[,,2])) #0.70
cor(colMeans(schedule1_multi_block2_pars$A[,,1]), colMeans(schedule1_multi_block2_pars$A[,,2])) #0.78
cor(colMeans(schedule1_multi_block3_pars$A[,,1]), colMeans(schedule1_multi_block3_pars$A[,,2])) #0.54

