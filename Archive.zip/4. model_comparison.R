rm(list=ls())
library(rstan)
library(loo)

extract_ic <- function(model_fit) {
  IC <- list()
  IC$LOOIC1 = loo(model_fit[[1]], save_psis = TRUE)
  IC$LOOIC2 = loo(model_fit[[2]], save_psis = TRUE)
  return(IC)
}

schedule1_multi_block1 <- readRDS("fitted_data/rat1_multi_block1_fit.rda")
schedule2_multi_block1 <- readRDS("fitted_data/rat2_multi_block1_fit.rda")
schedule1_multi_block2 <- readRDS("fitted_data/rat1_multi_block2_fit.rda")
schedule2_multi_block2 <- readRDS("fitted_data/rat2_multi_block2_fit.rda")
schedule1_multi_block3 <- readRDS("fitted_data/rat1_multi_block3_fit.rda")
schedule2_multi_block3 <- readRDS("fitted_data/rat2_multi_block3_fit.rda")
schedule1_multi_block4 <- readRDS("fitted_data/rat1_multi_block4_fit.rda")
schedule2_multi_block4 <- readRDS("fitted_data/rat2_multi_block4_fit.rda")

modelTable = data.frame(Model = NULL, LOOIC = NULL)
modelList = list(multi_block1 = list(schedule1_multi_block1, schedule2_multi_block1),
                 multi_block2 = list(schedule1_multi_block2, schedule2_multi_block2),
                 multi_block3 = list(schedule1_multi_block3, schedule2_multi_block3),
                 multi_block4 = list(schedule1_multi_block4, schedule2_multi_block4)) 

for (i in 1:length(modelList)) {
  modelTable[i, "Model"] = names(modelList)[i]
  modelTable[i, "LOOIC1"] = extract_ic(modelList[[i]])$LOOIC1$estimates[3,1]
  modelTable[i, "LOOIC2"] = extract_ic(modelList[[i]])$LOOIC2$estimates[3,1]
  modelTable[i, "LOOIC_SUM"] = modelTable[i, 'LOOIC1'] + modelTable[i, 'LOOIC2']
}
modelTable

