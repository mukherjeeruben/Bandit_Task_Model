fit_block_multi_model <- function(stable_data, volatile_data,schedule, model_name, save_name){
  
  stable_raw <- data.table::fread(file = paste0("clean_data/", stable_data, ".csv"),
                                  header = TRUE, sep = ",",  data.table = TRUE, fill = TRUE, 
                                  stringsAsFactors = TRUE, logical01 = FALSE)
  volatile_raw <- data.table::fread(file = paste0("clean_data/", volatile_data, ".csv"),
                                    header = TRUE, sep = ",",  data.table = TRUE, fill = TRUE, 
                                    stringsAsFactors = TRUE, logical01 = FALSE)
  stable_raw <- stable_raw %>% drop_na()
  volatile_raw <- volatile_raw %>% drop_na()
  payscale = 100
  
  DT_trials_stable <- stable_raw[, .N, by = "subjID"]
  DT_trials_volatile <- volatile_raw[, .N, by = "subjID"]
  DT_trials <- merge(DT_trials_stable, DT_trials_volatile, by = "subjID")
  
  subjs <- DT_trials$subjID
  n_subj <- length(subjs)
  t_subjs <- cbind(DT_trials$N.x, DT_trials$N.y)
  t_max     <- max(t_subjs)
  # Initialize (model-specific) data arrays 2 represents two conditions
  choice  <- array(-1, c(n_subj, t_max, 2))   ###recycle -1 array n_subj rows and t_max columns
  choiceB <- array(-1, c(n_subj, t_max, 2))
  outcome_blue <- array( -1, c(n_subj, t_max, 2))
  outcome <- array(-1, c(n_subj, t_max, 2))
  amount_blue <- array(0, c(n_subj, t_max, 2))
  amount_orange <- array(0, c(n_subj, t_max, 2))
  for(i in 1:n_subj){
    for(v in 1:2){
      subj <- subjs[i]
      t <- t_subjs[i, v]
      if(schedule == 1){
        if(v == 1){
          DT_subj <- stable_raw[stable_raw$subjID == subj]
        }else{
          DT_subj <- volatile_raw[volatile_raw$subjID == subj]
        }
      }else{
        if(v == 1){
          DT_subj <- volatile_raw[volatile_raw$subjID == subj]
        }else{
          DT_subj <- stable_raw[stable_raw$subjID == subj]
        }
      }
      choice[i, 1:t, v]  <- DT_subj$choice
      choiceB[i, 1:t, v] <- DT_subj$choiceB
      outcome_blue[i, 1:t, v] <- DT_subj$outcome_blue
      outcome[i, 1:t, v] <- DT_subj$outcome
      amount_blue[i, 1:t, v] <- DT_subj$amount_blue
      amount_orange[i, 1:t, v] <- DT_subj$amount_orange
    }
  }
  # Wrap into a list for Stan including both stable and volatile trials
  data_list <- list(
    N       = n_subj,
    T       = t_max,
    Tsubj   = t_subjs,
    choice  = choice,
    outcome_blue = outcome_blue,
    outcome = outcome,
    amount_blue = amount_blue / payscale,
    amount_orange = amount_orange / payscale,
    choiceB = choiceB) 
  
  fit <- stan(
    file = paste0("stan_files/", model_name),
    data = data_list,
    iter = 4000,
    warmup = 1000,
    chains = 4)
  saveRDS(fit, file = paste0("fitted_data/", save_name, "_fit.rda"))
  fit_extract <- rstan::extract(fit)
  output = list(list_data = data_list, fit = fit_extract)
  saveRDS(output, file = paste0("fitted_data/", save_name, ".rda"))
  return(output)
}
