# This script is used to plot posterior distributions of the group-level parameters
rm(list=ls())
library(rstan)
library(reshape2)
library(cowplot)
library(knitr)
library(dplyr)
source("utils/stan_rhat.R")
source("utils/plot_diff_HDI_info.R")
source("utils/plot_diff.R")
source("utils/HDIofMCMC.R")
source("utils/plot_utils.R")
source("utils/R_rainclouds.R")
source("utils/summarySE.R")

schedule1_stable <- readRDS("fitted_data/rat1_stable.rda")
schedule1_volatile <- readRDS("fitted_data/rat1_volatile.rda")
schedule2_stable <- readRDS("fitted_data/rat2_stable.rda")
schedule2_volatile <- readRDS("fitted_data/rat2_volatile.rda")

schedule1_stable_pars <- schedule1_stable[[3]][9:11] # 9:mu_A, 10:mu_beta, 11:mu_gamma
schedule1_volatile_pars <- schedule1_volatile[[3]][9:11]
schedule2_stable_pars <- schedule2_stable[[3]][9:11] # 9:mu_A, 10:mu_beta, 11:mu_gamma
schedule2_volatile_pars <- schedule2_volatile[[3]][9:11]

##### Basic Model ####

schedule1_pos = plot_posterior(groups = c("stable1", "volatile1", "stable2", "volatile2"), 
                               all_fits = list(stable1 = schedule1_stable_pars, 
                                               volatile1 = schedule1_volatile_pars,
                                               stable2 = schedule2_stable_pars,
                                               volatile2 = schedule2_volatile_pars),
                               color_scheme = c("stable1" = "#ffbdbc", "volatile1" = "#ee8e8e",
                               "stable2" = "#2d95db", "volatile2" = "#196090"),
                               name = "basic_all_pos")

plot_individual_change(schedule1_stable$fit, 
                       schedule1_volatile$fit,
                       schedule2_stable$fit,
                       schedule2_volatile$fit,
                       "basic_individual_change")


##### Multivariate normal distribution model #####

schedule1_multi_block1 <- readRDS("fitted_data/rat1_multi_block1_fit.rda")
schedule2_multi_block1 <- readRDS("fitted_data/rat2_multi_block1_fit.rda")
schedule1_multi_block2 <- readRDS("fitted_data/rat1_multi_block2_fit.rda")
schedule2_multi_block2 <- readRDS("fitted_data/rat2_multi_block2_fit.rda")
schedule1_multi_block3 <- readRDS("fitted_data/rat1_multi_block3_fit.rda")
schedule2_multi_block3 <- readRDS("fitted_data/rat2_multi_block3_fit.rda")

schedule1_multi_block1_pars <- rstan::extract(schedule1_multi_block1)
schedule2_multi_block1_pars <- rstan::extract(schedule2_multi_block1)
schedule1_multi_block2_pars <- rstan::extract(schedule1_multi_block2)
schedule2_multi_block2_pars <- rstan::extract(schedule2_multi_block2)
schedule1_multi_block3_pars <- rstan::extract(schedule1_multi_block3)
schedule2_multi_block3_pars <- rstan::extract(schedule2_multi_block3)
schedule1_multi_block4_pars <- rstan::extract(schedule1_multi_block4)
schedule2_multi_block4_pars <- rstan::extract(schedule2_multi_block4)

plot_posterior_multi_block(group1 = c("stable1", "volatile1"),
                           group2 = c("stable2", "volatile2"),
                           all_fits = list(schedule1_multi_block1_pars,
                                           schedule2_multi_block1_pars),
                           color_scheme = c("stable1" = "#ffbdbc", "volatile1" = "#ee8e8e",
                                            "stable2" = "#2d95db", "volatile2" = "#196090"),
                           name = "multi-block1_posterior")
plot_posterior_multi_block(group1 = c("stable1", "volatile1"),
                           group2 = c("stable2", "volatile2"),
                           all_fits = list(schedule1_multi_block2_pars,
                                           schedule2_multi_block2_pars),
                           color_scheme = c("stable1" = "#ffbdbc", "volatile1" = "#ee8e8e",
                                            "stable2" = "#2d95db", "volatile2" = "#196090"),
                           name = "multi-block2_posterior")

plot_posterior_multi_block(group1 = c("stable1", "volatile1"),
                           group2 = c("stable2", "volatile2"),
                           all_fits = list(schedule1_multi_block3_pars,
                                           schedule2_multi_block3_pars),
                           color_scheme = c("stable1" = "#ffbdbc", "volatile1" = "#ee8e8e",
                                            "stable2" = "#2d95db", "volatile2" = "#196090"),
                           name = "multi-block3_posterior")

plot_posterior_multi_block(group1 = c("stable1", "volatile1"),
                           group2 = c("stable2", "volatile2"),
                           all_fits = list(schedule1_multi_block4_pars,
                                           schedule2_multi_block4_pars),
                           color_scheme = c("stable1" = "#ffbdbc", "volatile1" = "#ee8e8e",
                                            "stable2" = "#2d95db", "volatile2" = "#196090"),
                           name = "multi-block4_posterior")

plot_individual_change_multi_block(schedule1_fit = schedule1_multi_block1, 
                                   schedule2_fit = schedule2_multi_block1,
                                   "multi_block1_individual")

plot_individual_change_multi_block(schedule1_fit = schedule1_multi_block2, 
                                   schedule2_fit = schedule2_multi_block2,
                                   "multi_block2_individual")
plot_individual_change_multi_block(schedule1_fit = schedule1_multi_block3, 
                                   schedule2_fit = schedule2_multi_block3,
                                   "multi_block3_individual")

plot_individual_change_multi_block(schedule1_fit = schedule1_multi_block4, 
                                   schedule2_fit = schedule2_multi_block4,
                                   "multi_block4_individual")

plot_individual_change_multi_block(schedule1_fit = schedule1_multi_block41, 
                                   schedule2_fit = schedule2_multi_block41,
                                   "multi_block41_individual")

##### posterior distribution of particular parameters #####
plot_par = function(par, par_name, df_name, file_name){
  par_df = as.data.frame(par[par_name])
  colnames(par_df) = df_name[1:2]
  par_df[df_name[3]] = par_df[,2] - par_df[,1]
  plot_title <- ggtitle(file_name)  
  pos = mcmc_areas(par_df, pars = df_name,
                   prob = 0.95, prob_outer = 0.99,
                   point_est = "mean") + 
    plot_title +
    theme(plot.title = element_text(size = 10, face = "bold"),
          text = element_text(size = 7))
  ggsave(filename=paste0("plots/multi_block/", file_name, ".png"),
         plot = pos, width = 3, height = 2)
}
plot_par(schedule1_multi_block1_pars, 'mu_A', 
         c('A_stable', 'A_volatile', 'A_diff'),
         "multi_block1_mu_A")
plot_par(schedule1_multi_block2_pars, 'mu_A', 
         c('A_stable', 'A_volatile', 'A_diff'),
         "multi_block2_mu_A")

