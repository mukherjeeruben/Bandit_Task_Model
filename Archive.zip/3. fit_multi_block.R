library(rstan)
library(bayesplot)
library(shinystan)
library(ggplot2)
library(cowplot)
library(abind)
library(dplyr)
library(ggpubr)
library(tidyr)
library(forcats)
source("utils/fit_block_multi_functions.R")
options(mc.cores = parallel::detectCores())
rstan_options(auto_write = TRUE)
rat1_block_multi = fit_block_multi_model(stable_data = "rat1_stable",
                                         volatile_data = "rat1_volatile",
                                         schedule = 1,
                                         model_name = "alt_block_multi_model1.stan",
                                         save_name = "rat1_block_multi1")

rat2_block_multi1 = fit_block_multi_model(stable_data = "rat2_stable",
                                          volatile_data = "rat2_volatile",
                                          schedule = 2,
                                          model_name = "alt_block_multi_model1.stan",
                                          save_name = "rat2_block_multi1")

