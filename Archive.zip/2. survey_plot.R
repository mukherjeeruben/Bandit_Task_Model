library(tidyverse)
survey1 = read.csv('original_data/survey1.csv')
survey2 = read.csv('original_data/survey2.csv')
rat1_clean = read.csv('clean_data/rat1_clean.csv')
rat2_clean = read.csv('clean_data/rat2_clean.csv')
## remove duplicated subjects, especially for survey 2 in which participants
# may click multiple times of submit
survey1 = survey1[!duplicated(survey1$participantId), ]
survey2 = survey2[!duplicated(survey2$participantId), ]

survey1_ID = unique(survey1$participantId)
survey2_ID = unique(survey2$participantId)
rat1_ID = unique(rat1_clean$subjID)
rat2_ID = unique(rat2_clean$subjID)

## survey1_clean contains only participants who completed both the surveys and task
survey1_clean = subset(survey1, survey1$participantId %in% c(rat1_ID, rat2_ID))
survey2_clean = subset(survey2, survey2$participantId %in% c(rat1_ID, rat2_ID))

survey1_clean['GCBS'] = rowMeans(survey1_clean[, 5:19])
survey2_clean['STAI'] = rowSums(survey2_clean[, 3:22])

write.csv(survey1_clean, 'clean_data/survey1_clean.csv')
write.csv(survey2_clean, 'clean_data/survey2_clean.csv')


mean_GCBS = colMeans(survey1_clean[, 5:19])
survey = merge(survey1_clean[, c('age', 'gender', 'participantId', 'GCBS')], 
               survey2_clean[, c('participantId', 'STAI')], by = "participantId")
survey_scale <- survey %>% mutate_at(c('GCBS', 'STAI'), ~(scale(.) %>% as.vector))

ggplot(survey_scale,aes(x=GCBS,y=STAI))+
         geom_point(size=2) +
         geom_smooth(method='lm', formula= y~x)+
         xlab('GCBS')+
         ylab('STAI')+
         theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
               panel.background = element_blank(), axis.line = element_line(colour = "black"))
p = lm(STAI ~ GCBS, data = survey_scale)         
summary(p)
ggplot(survey, aes(x = GCBS)) +
  geom_histogram(breaks=seq(1, 5, by=0.5), alpha = .5, col="black") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))
ggplot(survey, aes(x = STAI)) +
  geom_histogram(breaks=seq(20, 80, by=5), alpha = .5, col="black") +
  scale_y_continuous(breaks=seq(0,30,5)) +
  scale_x_continuous(breaks=seq(20,80,5)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))

