## The script for pre-processing the raw data
# import the original data: separate schedule1 subjects and schedule2 subjects
# rat_data includes both schedule1 and schedule2 data
rat_data = read.csv('original_data/rat.csv')
rat_schedule2 = read.csv('original_data/rat_schedule2.csv')
survey1 = read.csv('original_data/survey1.csv')
survey2 = read.csv('original_data/survey2.csv')

# subjects who completed the task (schedule1 or schedule2)
rat_ID = unique(rat_data$participantId)
rat2_ID = unique(rat_schedule2$participantId)
rat_schedule1 = subset(rat_data, !(rat_data$participantId %in% rat2_ID))
rat1_ID = unique(rat_schedule1$participantId)
# subjects who completed the two surveys (GCBS 1; STAI 2)
survey1_ID = unique(survey1$participantId)
survey2_ID = unique(survey2$participantId)
# unique IDs that are included both in the surveys and task
common_ID1 = intersect(intersect(rat1_ID, survey1_ID), survey2_ID)
common_ID2 = intersect(intersect(rat2_ID, survey1_ID), survey2_ID)

rat1_clean = subset(rat_schedule1, rat_schedule1$participantId %in% common_ID1)
rat2_clean = subset(rat_schedule2, rat_schedule2$participantId %in% common_ID2)

rat1_count = as.data.frame(table(rat1_clean$participantId))
rat2_count = as.data.frame(table(rat2_clean$participantId))
# only keep subjects who finished all trials
remove_subj1 = subset(rat1_count, (rat1_count$Freq %% 240) == 0) # 8 subjects are removed
remove_subj2 = subset(rat2_count, (rat2_count$Freq %% 240) == 0)

rat1_clean = subset(rat1_clean, rat1_clean$participantId %in% remove_subj1$Var1)
rat2_clean = subset(rat2_clean, rat2_clean$participantId %in% remove_subj2$Var1)
# 1: schedule1; 2: schedule2
location1 = c(0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1,
             0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 0,
             0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1,
             0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 
             0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 
             0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 
             0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0,
             1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 
             1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1,
             0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1,
             1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0,
             1, 1, 0, 0, 1, 1, 0, 1, 0)
correct1 = c(0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0,
            0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1,
            1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0,
            1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0,
            0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0,
            1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0,
            0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 
            0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1,
            1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0,
            0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0,
            1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0)
# location1 corresponds to the card1loc; location1 match with correct, blue doesn't steal
blue_outcome1 = rep(0, 240)
blue_outcome1[location1 != correct1] = 1
# card1loc == 0, blue_magnitiude = magnitude1; card1loc == 1, blue_magnitude = magnitude2
card1loc = as.logical(location1)
card1loc_op = as.logical(1-location1)
magnitude1 = c(65, 36, 13, 81, 66, 90, 24, 86, 27, 57, 4, 36, 51, 71, 85, 87, 62,
          52, 93, 89, 76, 93, 53, 56, 18, 82, 29, 54, 20, 14, 62, 96, 35, 59,
          5, 60, 2, 77, 13, 36, 5, 70, 21, 6, 45, 23, 35, 47, 95, 32, 62,
          22, 96, 9, 53, 75, 59, 2, 85, 79, 74, 74, 79, 22, 14, 16, 51, 5,
          37, 94, 96, 37, 20, 49, 12, 8, 91, 30, 48, 51, 47, 95, 70, 41, 11,
          78, 43, 83, 49, 16, 18, 73, 86, 35, 25, 82, 61, 14, 1, 98, 86, 2,
          35, 8, 26, 11, 58, 17, 18, 74, 71, 8, 4, 51, 34, 28, 80, 65, 18,
          66, 46, 63, 9, 19, 59, 93, 8, 53, 33, 45, 18, 86, 53, 14, 44, 76,
          1, 94, 79, 27, 84, 25, 20, 51, 36, 34, 91, 79, 3, 32, 40, 2, 34,
          82, 21, 21, 29, 33, 41, 97, 35, 32, 69, 44, 85, 54, 7, 44, 80, 1,
          62, 66, 82, 48, 24, 67, 3, 38, 72, 32, 75, 8, 42, 22, 82, 55, 3,
          60, 5, 23, 68, 37, 54, 67, 90, 13, 68, 19, 80, 12, 81, 34, 40, 9,
          80, 65, 84, 76, 13, 65, 32, 39, 8, 58, 78, 77, 56, 2, 53, 56, 51,
          49, 78, 61, 82, 60, 8, 91, 94, 54, 89, 2, 44, 77, 41, 34, 56, 23,
          86, 56)
magnitude2 = c(35, 64, 87, 19, 34, 10, 76, 14, 73, 43, 96, 64, 49, 29, 15, 13, 38,
               48, 7, 11, 24, 7, 47, 44, 82, 18, 71, 46, 80, 86, 38, 4, 65, 41,
               95, 40, 98, 23, 87, 64, 95, 30, 79, 94, 55, 77, 65, 53, 5, 68, 38,
               78, 4, 91, 47, 25, 41, 98, 15, 21, 26, 26, 21, 78, 86, 84, 49, 95,
               63, 6, 4, 63, 80, 51, 88, 92, 9, 70, 52, 49, 53, 5, 30, 59, 89,
               22, 57, 17, 51, 84, 82, 27, 14, 65, 75, 18, 39, 86, 99, 2, 14, 98,
               65, 92, 74, 89, 42, 83, 82, 26, 29, 92, 96, 49, 66, 72, 20, 35, 82,
               34, 54, 37, 91, 81, 41, 7, 92, 47, 67, 55, 82, 14, 47, 86, 56, 24,
               99, 6, 21, 73, 16, 75, 80, 49, 64, 66, 9, 21, 97, 68, 60, 98, 66,
               18, 79, 79, 71, 67, 59, 3, 65, 68, 31, 56, 15, 46, 93, 56, 20, 99,
               38, 34, 18, 52, 76, 33, 97, 62, 28, 68, 25, 92, 58, 78, 18, 45, 97,
               40, 95, 77, 32, 63, 46, 33, 10, 87, 32, 81, 20, 88, 19, 66, 60, 91,
               20, 35, 16, 24, 87, 35, 68, 61, 92, 42, 22, 23, 44, 98, 47, 44, 49,
               51, 22, 39, 18, 40, 92, 9, 6, 46, 11, 98, 56, 23, 59, 66, 44, 77,
               14, 44)
blue_magnitude1 = rep(0, 240)
blue_magnitude1[card1loc] = magnitude2[card1loc]
blue_magnitude1[card1loc_op] = magnitude1[card1loc_op]

data_clean1 = data.frame(matrix(ncol = 12, nrow = 0))
colnames(data_clean1) = names(rat1_clean)
for(i in 1:length(remove_subj1$Var1)){
  data = subset(rat1_clean, rat1_clean$participantId == remove_subj1$Var1[i])
  data = data[1:240, ]
  data['amount_blue'] = blue_magnitude1
  data['amount_orange'] = 100 - blue_magnitude1
  data['outcome_blue'] = blue_outcome1
  data['trial'] = seq(1:240)
  # if(nrow(data) %% 240 == 0){
  #   data = data[1:240,]
  # }else if(nrow(data) %% 239 == 0){
  #   data = data[1:239,]
  # }else if(nrow(data) %% 238 == 0){
  #   data = data[1:238,]
  # }else if(nrow(data) %% 234 == 0){
  #   data = data[1:234,]
  # } 
  data_clean1 = rbind(data_clean1, data)
}
colnames(data_clean1)[7] = "subjID"

location2 = c(0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1,
              0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 
              1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1,
              1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1,
              0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1,
              0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0,
              0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 
              1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1,
              1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 
              1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 
              0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0,
              0, 1, 1, 1, 1, 1, 0, 1, 1)
correct2 = c(1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0,
             1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 
             1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0,
             0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1,
             1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0,
             0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0,
             0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
             1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1,
             0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1,
             1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 0,
             0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0,
             0, 1, 1, 1, 0, 1, 0, 1, 0)
blue_outcome2 = rep(0, 240)
blue_outcome2[location2 != correct2] = 1
# card1loc == 0, blue_magnitiude = magnitude1; card1loc == 1, blue_magnitude = magnitude2
card2loc = as.logical(location2)
card2loc_op = as.logical(1-location2)

magnitude1 = c(46, 63, 9, 19, 59, 93, 8, 53, 33, 45, 18, 86, 53, 14, 44,
               76, 1, 94, 79, 27, 84, 25, 20, 51, 36, 34, 91, 79, 3, 32,
               40, 2, 34, 82, 21, 21, 29, 33, 41, 97, 35, 32, 69, 44, 85,
               54, 7, 44, 80, 1, 62, 66, 82, 48, 24, 67, 3, 38, 72, 32,
               75, 8, 42, 22, 82, 55, 3, 60, 5, 23, 68, 37, 54, 67, 90,
               13, 68, 19, 80, 12, 81, 34, 40, 9, 80, 65, 84, 76, 13, 65,
               32, 39, 8, 58, 78, 77, 56, 2, 53, 56, 51, 49, 78, 61, 82,
               60, 8, 91, 94, 54, 89, 2, 44, 77, 41, 34, 56, 23, 86, 56,
               65, 36, 13, 81, 66, 90, 24, 86, 27, 57, 4, 36, 51, 71, 85, 87, 62, 52, 93, 89,
               76, 93, 53, 56, 18, 82, 29, 54, 20, 14, 62, 96, 35, 59, 5, 60, 2, 77, 13, 36,
               5, 70, 21, 6, 45, 23, 35, 47, 95, 32, 62, 22, 96, 9, 53, 75, 59, 2, 85, 79,
               74, 74, 79, 22, 14, 16, 51, 5, 37, 94, 96, 37, 20, 49, 12, 8, 91, 30, 48, 51,
               47, 95, 70, 41, 11, 78, 43, 83, 49, 16, 18, 73, 86, 35, 25, 82, 61, 14, 1, 98,
               86, 2, 35, 8, 26, 11, 58, 17, 18, 74, 71, 8, 4, 51, 34, 28, 80, 65, 18, 66)

magnitude2 = c(54, 37, 91, 81, 41, 7, 92, 47, 67, 55, 82, 14, 47, 86, 56,
               24, 99, 6, 21, 73, 16, 75, 80, 49, 64, 66, 9, 21, 97, 68,
               60, 98, 66, 18, 79, 79, 71, 67, 59, 3, 65, 68, 31, 56, 15,
               46, 93, 56, 20, 99, 38, 34, 18, 52, 76, 33, 97, 62, 28, 68,
               25, 92, 58, 78, 18, 45, 97, 40, 95, 77, 32, 63, 46, 33, 10,
               87, 32, 81, 20, 88, 19, 66, 60, 91, 20, 35, 16, 24, 87, 35,
               68, 61, 92, 42, 22, 23, 44, 98, 47, 44, 49, 51, 22, 39, 18,
               40, 92, 9, 6, 46, 11, 98, 56, 23, 59, 66, 44, 77, 14, 44,
               35, 64, 87, 19, 34, 10, 76, 14, 73, 43, 96, 64, 49, 29, 15, 13, 38, 48, 7, 11,
               24, 7, 47, 44, 82, 18, 71, 46, 80, 86, 38, 4, 65, 41, 95, 40, 98, 23, 87, 64,
               95, 30, 79, 94, 55, 77, 65, 53, 5, 68, 38, 78, 4, 91, 47, 25, 41, 98, 15, 21,
               26, 26, 21, 78, 86, 84, 49, 95, 63, 6, 4, 63, 80, 51, 88, 92, 9, 70, 52, 49,
               53, 5, 30, 59, 89, 22, 57, 17, 51, 84, 82, 27, 14, 65, 75, 18, 39, 86, 99, 2,
               14, 98, 65, 92, 74, 89, 42, 83, 82, 26, 29, 92, 96, 49, 66, 72, 20, 35, 82, 34)

blue_magnitude2 = rep(0, 240)
blue_magnitude2[card2loc] = magnitude2[card2loc]
blue_magnitude2[card2loc_op] = magnitude1[card2loc_op]
data_clean2 = data.frame(matrix(ncol = 13, nrow = 0))
colnames(data_clean2) = names(rat2_clean)

for(i in 1:length(remove_subj2$Var1)){
  data = subset(rat2_clean, rat2_clean$participantId == remove_subj2$Var1[i])
  data = data[1:240, ]
  data['amount_blue'] = blue_magnitude2
  data['amount_orange'] = 100 - blue_magnitude2
  data['outcome_blue'] = blue_outcome2
  data['trial'] = seq(1:240)
  # if(nrow(data) %% 240 == 0){
  #   data = data[1:240,]
  # }else if(nrow(data) %% 239 == 0){
  #   data = data[1:239,]
  # }else if(nrow(data) %% 238 == 0){
  #   data = data[1:238,]
  # }else if(nrow(data) %% 234 == 0){
  #   data = data[1:234,]
  # } 
  data_clean2 = rbind(data_clean2, data)
}
colnames(data_clean2)[7] = "subjID"

## mutate the clean df
library(dplyr)
data_clean1 <- data_clean1 %>%
  mutate(status = if_else(trial%in% seq(1,120), -1, 1),
         out = if_else(outcome == 0, 1, -1),
         choiceB = if_else(choice == 1, 1, 0))

data_clean2 <- data_clean2 %>%
  mutate(status = if_else(trial%in% seq(1,120), 1, -1),
         out = if_else(outcome == 0, 1, -1),
         choiceB = if_else(choice == 1, 1, 0))

data_clean1_count = as.data.frame(table(data_clean1$subjID))
data_clean2_count = as.data.frame(table(data_clean2$subjID))

write.csv(data_clean1, "clean_data/rat1_clean.csv", row.names = FALSE)
write.csv(data_clean2, "clean_data/rat2_clean.csv", row.names = FALSE)
write.table(data_clean1, "clean_data/rat1_clean.txt", row.names = FALSE)
write.table(data_clean2, "clean_data/rat2_clean.txt", row.names = FALSE)

######## separate stable and volatile block ############ 
rat1_clean = read.csv('clean_data/rat1_clean.csv')
rat1_stable = subset(rat1_clean, rat1_clean$trial %in% seq(1,120))
rat1_volatile = subset(rat1_clean, rat1_clean$trial %in% seq(121,240))
write.csv(rat1_stable, 'clean_data/rat1_stable.csv', row.names = FALSE)
write.csv(rat1_volatile, 'clean_data/rat1_volatile.csv', row.names = FALSE)
write.table(rat1_stable, "clean_data/rat1_stable.txt", row.names = FALSE)
write.table(rat1_volatile, "clean_data/rat1_volatile.txt", row.names = FALSE)


rat2_clean = read.csv('clean_data/rat2_clean.csv')
rat2_volatile = subset(rat2_clean, rat2_clean$trial %in% seq(1,120))
rat2_stable = subset(rat2_clean, rat2_clean$trial %in% seq(121,240))
write.csv(rat2_stable, 'clean_data/rat2_stable.csv', row.names = FALSE)
write.csv(rat2_volatile, 'clean_data/rat2_volatile.csv', row.names = FALSE)
write.table(rat2_stable, "clean_data/rat2_stable.txt", row.names = FALSE)
write.table(rat2_volatile, "clean_data/rat2_volatile.txt", row.names = FALSE)
